import { GoogleGenAI } from "@google/genai";
import { AnalysisResult } from "../types";

// Initialize Gemini
// CRITICAL: process.env.API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeCompanySentiment = async (query: string): Promise<AnalysisResult> => {
  const modelId = "gemini-3-pro-preview";

  const prompt = `
    Analyze the public sentiment for the company or website: "${query}".
    
    1. Search the web for reviews, discussions, and ratings on platforms like Reddit, Trustpilot, G2, ProductHunt, Twitter/X, and Quora.
    2. Identify key themes (Pricing, Support, UI/UX, Reliability, Features).
    3. Aggregate the sentiment into an overall score and distribution.
    4. Extract specific pros and cons.
    5. Synthesize representative "reviews" or snippets based on the search results found.
    
    CRITICAL: Output ONLY valid JSON. Do not include markdown code blocks. Do not include introductory text.
    
    Structure:
    {
      "companyName": "string",
      "websiteUrl": "string (optional)",
      "overallScore": number (0-100),
      "sentimentDistribution": { "positive": number, "neutral": number, "negative": number }, // adds up to 100
      "summary": "string",
      "pros": ["string"],
      "cons": ["string"],
      "topics": [{ "topic": "string", "sentimentScore": number (0-100), "volume": number, "summary": "string" }],
      "reviews": [{ "platform": "string", "url": "string", "snippet": "string", "sentiment": "Positive" | "Neutral" | "Negative", "date": "string" }]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }], // Enable search grounding to "scrape" data
      },
    });

    let text = response.text;
    if (!text) {
      throw new Error("No response from Gemini");
    }

    // Robust JSON extraction: Find the first '{' and the last '}'
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      text = jsonMatch[0];
    } else {
      // Fallback: simple cleanup if regex fails
      text = text.replace(/^```json\s*/, "").replace(/```$/, "").trim();
    }

    const data = JSON.parse(text) as AnalysisResult;
    
    return data;
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    throw error;
  }
};