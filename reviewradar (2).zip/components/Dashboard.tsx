import React from 'react';
import { AnalysisResult } from '../types';
import SentimentOverview from './SentimentOverview';
import TopicBreakdown from './TopicBreakdown';
import ReviewFeed from './ReviewFeed';
import { Download, ThumbsUp, ThumbsDown, Globe } from 'lucide-react';

interface DashboardProps {
  data: AnalysisResult;
}

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const downloadCSV = () => {
    if (!data) return;
    const headers = ['Type', 'Platform', 'Sentiment', 'Content', 'Date'];
    const rows = data.reviews.map(r => 
      ['Review', r.platform, r.sentiment, `"${r.snippet.replace(/"/g, '""')}"`, r.date || ''].join(',')
    );
    const topicRows = data.topics.map(t =>
      ['Topic', 'All', `${t.sentimentScore}%`, `"${t.topic} - ${t.summary.replace(/"/g, '""')}"`, ''].join(',')
    );
    const csvContent = [headers.join(','), ...rows, ...topicRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${data.companyName}_sentiment_analysis.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-2 border-b border-gray-100">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 flex items-center gap-3">
            {data.companyName}
            {data.websiteUrl && (
              <a href={data.websiteUrl} target="_blank" rel="noreferrer" className="group">
                <Globe className="w-5 h-5 text-slate-300 group-hover:text-violet-500 transition-colors" />
              </a>
            )}
          </h2>
          <p className="text-slate-500 font-medium mt-2">Analyzed {data.reviews.length} sources across the web</p>
        </div>
        <button 
          onClick={downloadCSV}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm"
        >
          <Download className="w-4 h-4" />
          Export Report
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Stats & Topics */}
        <div className="lg:col-span-2 space-y-8">
          <SentimentOverview data={data} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
                <div className="p-1.5 bg-green-100 rounded-lg">
                  <ThumbsUp className="w-4 h-4 text-green-600" />
                </div>
                Key Strengths
              </h3>
              <ul className="space-y-4 flex-1">
                {data.pros.map((pro, i) => (
                  <li key={i} className="flex gap-4 text-sm font-medium text-slate-600 leading-relaxed">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2 shrink-0 shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                    {pro}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex flex-col">
               <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
                <div className="p-1.5 bg-red-100 rounded-lg">
                  <ThumbsDown className="w-4 h-4 text-red-600" />
                </div>
                Key Weaknesses
              </h3>
              <ul className="space-y-4 flex-1">
                {data.cons.map((con, i) => (
                  <li key={i} className="flex gap-4 text-sm font-medium text-slate-600 leading-relaxed">
                     <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 shrink-0 shadow-[0_0_8px_rgba(239,68,68,0.6)]" />
                    {con}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <TopicBreakdown topics={data.topics} />
        </div>

        {/* Right Column: Review Feed */}
        <div className="lg:col-span-1 h-full min-h-[500px]">
          <ReviewFeed reviews={data.reviews} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;