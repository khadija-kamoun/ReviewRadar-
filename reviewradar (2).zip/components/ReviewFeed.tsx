import React, { useState } from 'react';
import { AnalysisResult, Sentiment, ReviewSource } from '../types';
import { MessageSquare, ExternalLink, Filter, Quote } from 'lucide-react';

interface ReviewFeedProps {
  reviews: ReviewSource[];
}

const ReviewFeed: React.FC<ReviewFeedProps> = ({ reviews }) => {
  const [filter, setFilter] = useState<'All' | Sentiment>('All');

  const filteredReviews = reviews.filter(
    (review) => filter === 'All' || review.sentiment === filter
  );

  const getSentimentBadge = (sentiment: Sentiment) => {
    switch (sentiment) {
      case Sentiment.POSITIVE:
        return <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-violet-100 text-violet-700">Positive</span>;
      case Sentiment.NEUTRAL:
        return <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-slate-100 text-slate-600">Neutral</span>;
      case Sentiment.NEGATIVE:
        return <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-pink-100 text-pink-700">Negative</span>;
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm h-full flex flex-col hover:shadow-lg hover:shadow-violet-500/5 transition-shadow">
      <div className="flex flex-col gap-6 mb-6">
        <h3 className="text-xl font-bold text-slate-900">Live Remarks</h3>
        
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {(['All', Sentiment.POSITIVE, Sentiment.NEUTRAL, Sentiment.NEGATIVE] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                filter === s
                  ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/20'
                  : 'bg-white border border-gray-200 text-slate-600 hover:border-violet-300 hover:text-violet-600'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4 flex-1 overflow-y-auto max-h-[600px] pr-2 custom-scrollbar">
        {filteredReviews.length === 0 ? (
          <div className="text-center py-16 text-slate-400">
            <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="font-medium">No reviews found matching this filter.</p>
          </div>
        ) : (
          filteredReviews.map((review, idx) => (
            <div key={idx} className="p-5 rounded-2xl border border-gray-100 bg-white hover:border-violet-200 hover:shadow-md transition-all duration-300 group relative">
              <Quote className="absolute top-4 left-4 w-4 h-4 text-violet-200" />
              <div className="flex justify-between items-start gap-4 mb-3 pl-6">
                <div className="flex flex-col">
                  <span className="font-bold text-sm text-slate-900">{review.platform}</span>
                  <span className="text-xs text-slate-400 font-medium">{review.date || 'Just now'}</span>
                </div>
                {getSentimentBadge(review.sentiment)}
              </div>
              
              <p className="text-sm text-slate-600 leading-relaxed mb-4 font-medium pl-6">
                "{review.snippet}"
              </p>
              
              <div className="flex justify-end pl-6">
                {review.url && (
                    <a 
                    href={review.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-xs font-bold text-violet-600 hover:text-violet-700 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                    View Source
                    <ExternalLink className="w-3 h-3" />
                    </a>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ReviewFeed;