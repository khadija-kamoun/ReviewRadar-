import React from 'react';
import { AnalysisResult, TopicInsight } from '../types';

interface TopicBreakdownProps {
  topics: TopicInsight[];
}

const TopicBreakdown: React.FC<TopicBreakdownProps> = ({ topics }) => {
  const getBarColor = (score: number) => {
    if (score >= 70) return 'bg-gradient-to-r from-violet-500 to-violet-400';
    if (score >= 40) return 'bg-gradient-to-r from-orange-400 to-amber-400';
    return 'bg-gradient-to-r from-pink-500 to-rose-500';
  };

  const getTextColor = (score: number) => {
    if (score >= 70) return 'text-violet-600';
    if (score >= 40) return 'text-amber-600';
    return 'text-rose-600';
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm hover:shadow-lg hover:shadow-violet-500/5 transition-shadow">
      <h3 className="text-xl font-bold text-slate-900 mb-8">Deep Dive Analysis</h3>
      <div className="space-y-8">
        {topics.map((topic) => (
          <div key={topic.topic} className="group">
            <div className="flex justify-between items-end mb-3">
              <div className="flex items-center gap-3">
                <span className="font-bold text-slate-900 text-lg">{topic.topic}</span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-xs font-bold text-slate-500">
                  Vol: {topic.volume}/10
                </span>
              </div>
              <div className="text-right">
                <span className={`text-xl font-extrabold ${getTextColor(topic.sentimentScore)}`}>
                  {topic.sentimentScore}%
                </span>
              </div>
            </div>
            
            <div className="w-full bg-slate-100 rounded-full h-3 mb-3 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-1000 ${getBarColor(topic.sentimentScore)}`}
                style={{ width: `${topic.sentimentScore}%` }}
              ></div>
            </div>
            
            <p className="text-sm text-slate-500 leading-relaxed font-medium">
              {topic.summary}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopicBreakdown;