import React from 'react';
import { Github } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="w-full border-b border-gray-100 sticky top-0 z-50 glass-panel h-36">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        <div className="flex items-center gap-6">
          <a href="#" className="flex items-center gap-5 hover:opacity-90 transition-opacity">
            <img 
              src="https://khadijakamoun.com/wp-content/uploads/2025/07/LOGO.png" 
              alt="Khadija Kamoun Logo" 
              className="w-32 h-32 object-contain"
            />
            <div className="flex flex-col justify-center">
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight leading-none">
                Review<span className="text-violet-600">Radar</span>
              </h1>
              <span className="text-sm font-bold text-slate-500 mt-1">
                by Khadija Kamoun
              </span>
            </div>
          </a>
        </div>
        
        <div className="flex items-center gap-6">
          <nav className="hidden md:flex gap-8">
            <a href="#" className="text-sm font-semibold text-slate-500 hover:text-slate-900 transition-colors">Methodology</a>
            <a href="#" className="text-sm font-semibold text-slate-500 hover:text-slate-900 transition-colors">Use Cases</a>
          </nav>
          <button className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors bg-white/50 px-4 py-2 rounded-full border border-gray-200 hover:border-violet-200 hover:bg-violet-50/50">
            <Github className="w-4 h-4" />
            <span className="hidden sm:inline text-sm font-bold">Star on GitHub</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;