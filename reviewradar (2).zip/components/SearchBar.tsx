import React, { useState } from 'react';
import { Search, Loader2, Sparkles } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto relative z-10">
      <form onSubmit={handleSubmit} className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
        <div className="relative bg-white rounded-2xl shadow-xl flex items-center p-2 border border-gray-100">
          <div className="pl-4 pr-2 flex items-center pointer-events-none">
            {isLoading ? (
              <Loader2 className="h-6 w-6 text-violet-500 animate-spin" />
            ) : (
              <Search className="h-6 w-6 text-slate-400" />
            )}
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={isLoading}
            className="flex-1 w-full px-3 py-4 bg-transparent text-slate-900 placeholder-slate-400 focus:outline-none text-lg font-medium"
            placeholder="Enter company (e.g. 'Stripe' or 'stripe.com')"
          />
          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="px-6 py-3 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white rounded-xl font-bold transition-all transform active:scale-95 flex items-center gap-2 shadow-lg shadow-slate-900/20"
          >
            {isLoading ? 'Scanning...' : 'Analyze'}
            {!isLoading && <Sparkles className="w-4 h-4 text-fuchsia-400" />}
          </button>
        </div>
      </form>
      <div className="mt-4 flex items-center justify-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wide">
        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
        Powered by Gemini 2.0 Flash
      </div>
    </div>
  );
};

export default SearchBar;