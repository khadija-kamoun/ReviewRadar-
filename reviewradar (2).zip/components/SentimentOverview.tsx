import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { AnalysisResult } from '../types';

interface SentimentOverviewProps {
  data: AnalysisResult;
}

const SentimentOverview: React.FC<SentimentOverviewProps> = ({ data }) => {
  const chartData = [
    { name: 'Positive', value: data.sentimentDistribution.positive, color: '#8b5cf6' }, // Violet 500
    { name: 'Neutral', value: data.sentimentDistribution.neutral, color: '#cbd5e1' },  // Slate 300
    { name: 'Negative', value: data.sentimentDistribution.negative, color: '#ec4899' }, // Pink 500
  ];

  return (
    <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm hover:shadow-lg hover:shadow-violet-500/5 transition-shadow">
      <h3 className="text-xl font-bold text-slate-900 mb-8">Sentiment Overview</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        <div className="h-64 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={65}
                outerRadius={85}
                paddingAngle={6}
                dataKey="value"
                stroke="none"
                cornerRadius={6}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '12px', 
                  border: 'none', 
                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                  padding: '12px',
                  fontFamily: 'Plus Jakarta Sans'
                }}
                itemStyle={{ color: '#0f172a', fontWeight: 600, fontSize: '13px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          {/* Center Score */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-4xl font-extrabold text-slate-900">{data.overallScore}</span>
            <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Trust Score</span>
          </div>
        </div>

        <div className="space-y-6">
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
            <p className="text-xs font-bold text-violet-600 uppercase tracking-wide mb-2">AI Summary</p>
            <p className="text-slate-600 text-sm leading-7 font-medium">
              {data.summary}
            </p>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
             {chartData.map((item) => (
               <div key={item.name} className="flex flex-col items-center p-3 rounded-2xl bg-white border border-gray-100 shadow-sm">
                 <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">{item.name}</span>
                 <span className="text-xl font-bold mt-1" style={{ color: item.color }}>{item.value}%</span>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SentimentOverview;