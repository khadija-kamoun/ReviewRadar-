import React from 'react';
import { Loader2 } from 'lucide-react';

const LoadingState: React.FC = () => {
  return (
    <div className="w-full h-96 flex flex-col items-center justify-center space-y-6 bg-white/50 backdrop-blur-sm rounded-3xl border border-gray-100">
      <div className="relative">
        <div className="absolute inset-0 bg-violet-400 rounded-full animate-ping opacity-20"></div>
        <div className="absolute inset-0 bg-fuchsia-400 rounded-full animate-ping opacity-20 animation-delay-500"></div>
        <div className="relative bg-white p-5 rounded-full shadow-xl shadow-violet-100 border border-gray-50">
          <Loader2 className="w-8 h-8 text-violet-600 animate-spin" />
        </div>
      </div>
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold text-slate-900">Gathering Intelligence</h3>
        <p className="text-sm font-medium text-slate-500 max-w-xs mx-auto">
          Scanning Reddit, G2, and social channels...
        </p>
      </div>
    </div>
  );
};

export default LoadingState;